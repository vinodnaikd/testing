<?php

namespace App\Http\Controllers;

use App\RiskQuestions;
use Illuminate\Http\Request;

class RiskQuestionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\RiskQuestions  $riskQuestions
     * @return \Illuminate\Http\Response
     */
    public function show(RiskQuestions $riskQuestions)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\RiskQuestions  $riskQuestions
     * @return \Illuminate\Http\Response
     */
    public function edit(RiskQuestions $riskQuestions)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\RiskQuestions  $riskQuestions
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RiskQuestions $riskQuestions)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\RiskQuestions  $riskQuestions
     * @return \Illuminate\Http\Response
     */
    public function destroy(RiskQuestions $riskQuestions)
    {
        //
    }
}
