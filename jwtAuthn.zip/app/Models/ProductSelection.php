<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductSelection extends Model
{
  protected $fillable =
[
    'productname',
    'scenario one products',
    'amount',
    'scenario two products',
];
}
