<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DashboardRecordsInfo extends Model
{
  protected $fillable =
[
   'Equity',
   'Debt',
   'Gold',
   'Graph',
];
}
