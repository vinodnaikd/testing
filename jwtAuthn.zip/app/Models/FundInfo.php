<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FundInfo extends Model
{
  protected $fillable =
[
    ' Equity',
    'Gold',
    'debt',
    'fund_id',
];
}
