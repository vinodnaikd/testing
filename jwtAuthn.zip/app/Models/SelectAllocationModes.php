<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SelectAllocationModes extends Model
{
  protected $fillable =
[
    'lumpsum',
    'Sip',
];
}
